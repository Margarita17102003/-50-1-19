/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package game2;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;


public class Game2 extends JFrame {

    private static Game2 game_window;
    private static long last_frame_time;
    private static Image mono;
    private static Image game_over;
    private static Image drop;
    private static Image russia;
    public static float russia_left=20;
    public static float russia_top=20;
    private static float drop_left = 200;
    private static float drop_top = -200;
    private static float drop_v = 200;
    private static int score = 0;
    
    public static void main (String[] args) throws IOException{
     // Дммитриева Маргарита
  
    game_window = new Game2();
    game_window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    game_window.setLocation(200, 60);
    game_window.setSize(1100, 820);
    game_window.setResizable(false);
    last_frame_time = System.nanoTime();
    GameField game_field = new GameField();
    game_window.add(game_field);
    game_window.setVisible(true);
    drop = ImageIO.read(Game2.class.getResourceAsStream("drop.png"));
    mono = ImageIO.read(Game2.class.getResourceAsStream("mono.png"));
    russia = ImageIO.read(Game2.class.getResourceAsStream("russia.png"));
    game_over = ImageIO.read(Game2.class.getResourceAsStream("game_over.png"));
    
            game_field.addMouseListener(new MouseAdapter() { 
            @Override
            public void mousePressed(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                float drop_right = drop_left + drop.getWidth(null);
                float drop_bottom = drop_top + drop.getHeight(null);
                boolean is_drop = x >= drop_left && x <= drop_right && y >= drop_top && y <= drop_bottom;
                
                if (is_drop) {
                    drop_top = -100; 
                    drop_left = (int) (Math.random() * (game_field.getWidth() - drop.getWidth(null))); 
                    drop_v = drop_v + 10; 
                    score++; 
                    game_window.setTitle("Score: " + score); //Дмитриева м.м.
                }
            }
        });
    
    }
    //Дмитриева Маргарита
    private static void onRepaint(Graphics g){
        long current_time = System.nanoTime();
        float delt_time = (current_time - last_frame_time) * 0.000000001f;
        last_frame_time = current_time;
        
        drop_top = drop_top + drop_v * delt_time;
        g.drawImage(mono, 0, 0, null); 
        g.drawImage(drop, (int) drop_left, (int) drop_top, null);
        g.drawImage(russia,(int)russia_left,(int)russia_top,null);
        if(drop_top > game_window.getHeight()) g.drawImage(game_over, -10, -140, null); 

    }
    
    public static class GameField extends JPanel{
    
        @Override
        protected void paintComponent(Graphics g){
        super.paintComponent(g);
        onRepaint(g);
        repaint();
    }   
}
}


